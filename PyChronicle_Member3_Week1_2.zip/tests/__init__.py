"""Test suite for PyChronicle.
"""
