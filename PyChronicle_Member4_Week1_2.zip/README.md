# PyChronicle — Time-Travel Debugger

PyChronicle is an execution tracer that records program runtime events and variable states into SQLite, allowing developers to step through code execution history in an interactive terminal dashboard.

This branch contains the **Member 4 (Textual UI) — Weeks 1 & 2** implementation.

---

## What's Included (Weeks 1 & 2)

- **Textual Application (`pychronicle.ui.app`):** Dual-pane terminal dashboard connecting the code viewer, variable state table, and timeline scrubber.
- **Code Viewer (`pychronicle.ui.code_viewer`):** Python syntax highlighting (via Rich/Pygments), execution line pointer, and auto-scrolling to keep the active line in view.
- **Timeline Slider (`pychronicle.ui.timeline`):** Execution step scrubber with progress indicator, step navigation (first, prev, play/pause, next, last), and adjustable playback speeds.
- **Variable Viewer (`pychronicle.ui.variable_viewer`):** Live table displaying local variables with diff indicators (`MOD` for modified values, `NEW` for initialized variables).
- **Storage Integration:** Connected directly to Member 3's SQLite backend (`StorageManager`) to consume trace events and variable states.
- **Automated Tests:** 40 passing unit and UI tests covering all components and interactions.

---

## Quickstart

### 1. Setup Environment
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Run the Interactive Demo
```bash
python demo_week1_week2_tui.py
```

### 3. Run Tests
```bash
pytest -v tests/
```

---

## Keyboard Shortcuts

| Key | Action | Description |
| :--- | :--- | :--- |
| `Right` / `l` | `step_forward` | Step forward 1 line |
| `Left` / `h` | `step_backward` | Step backward 1 line |
| `Home` / `g` | `jump_start` | Jump to step 1 (beginning) |
| `End` / `G` | `jump_end` | Jump to last step |
| `Space` / `p` | `toggle_play` | Toggle autoplay |
| `f` | `focus_filter` | Focus variable search / filter bar |
| `?` | `show_help` | Show keyboard shortcuts modal |
| `q` / `Ctrl+C` | `quit` | Exit application |

---

## Project Structure

```text
pychronicle/
  ├── ui/                     # Member 4: Textual UI components
  │   ├── app.py              # Main application scaffolding
  │   ├── code_viewer.py      # Code viewer with syntax highlighting
  │   ├── timeline.py         # Timeline slider scrubber & playback
  │   ├── variable_viewer.py  # Variable inspection table
  │   └── modals.py           # Help dialog
  └── storage/                # Member 3: SQLite storage engine backend
tests/
  ├── test_ui_week1_week2.py  # Dedicated Weeks 1 & 2 scaffolding tests
  ├── test_ui.py              # Comprehensive UI behavior tests
  └── test_*.py               # Storage backend tests
demo_week1_week2_tui.py       # Interactive terminal demo launcher
run_tui.py                    # CLI launcher
UI_DOCS.md                    # Technical documentation
MEMBER4_WEEK1_WEEK2_BRIEFING.txt # Member 4 briefing guide
```
